Doctor Biz, the three candidate reads succeeded. The observed states are: open finding with no acceptance, locally supported acceptance after resolution, and unresolved concurrent acceptance/rejection. I did not select a winner in the conflict case.

I used the supplied compiled CLI and capture recipe only. I read no repository code, tests, fixtures, driver, oracle, broad reports, or prior transcripts. I made no store changes or index rebuilds.

All scenarios selected namespace `org/example/development` and subject `widget/task-1`. Every event source shown below uses repository `synthetic/widget`.

The returned interpretation bindings were identical:

| Binding | Exact value |
|---|---|
| Profile digest | `sha256:b89dd93eb851ca4db63e9e29fbd1d060310f2268c8d37ed00c46004f2eafeab9` |
| Policy digest | `sha256:e9d050d6b7170e608677c0c56b338a888c2ec001499b0119adca52cf0c8fd437` |
| Projector version | `development/projector/v1` |
| Projector digest | `sha256:9d7c69c89cad7a81333d6b71a9da3c0ad8211ceb4621afa69fbc8361d157c267` |

Each request omitted `--frontier`. Each brief returned its captured namespace frontier. I did not run a separate heads read or establish an atomic relationship between index readiness and frontier capture.

**Open scenario**

Repository: `/tmp/pact-guide-readers-b1e00dd/open`.

Requested source revision: `62ba249ef5cafdee4860900220f826dfad0ba869`.

Returned frontier:

`sha256:51436a515b62b9c6f02adba580d70cdbcfdabbb5a687c9573a9e84029b9ca628`

Exact event references:

| Label | Full event reference |
|---|---|
| Check | `pact:event:sha256:51436a515b62b9c6f02adba580d70cdbcfdabbb5a687c9573a9e84029b9ca628#check` |
| Review | `pact:event:sha256:51436a515b62b9c6f02adba580d70cdbcfdabbb5a687c9573a9e84029b9ca628#review` |
| Action | `pact:event:sha256:51436a515b62b9c6f02adba580d70cdbcfdabbb5a687c9573a9e84029b9ca628#next` |

The Check reports name `unit`, command `["go","test","./..."]`, outcome `passed`, exit code `0`, and operation ID `initial`. Its exact source revision is `62ba249ef5cafdee4860900220f826dfad0ba869`. It selects evidence index `0`.

The Review owns `finding-1`, severity `important`, summary “Synthetic input loses a declared fact.” The finding has that same source revision. Its status is `open`, and `resolved_by` is empty. The brief does not expose the original review verdict or complete review payload.

`recorded_decisions` is empty. `supported_acceptance.status` is `not_recorded`, with no decision refs or reasons. The passed check does not resolve the Important finding or establish acceptance.

The Action declares “Correct finding-1 and review the correction.” Its actor is `fixture-agent`, operation ID is `initial`, and source revision is `62ba249ef5cafdee4860900220f826dfad0ba869`. Its payload names `local:review` in both `blocking_event_refs` and the blocking finding entry for `finding-1`. That local ref resolves to the full Review ref above. Its selected evidence list is empty. This action matches the requested source and its finding remains open; it is a recorded declaration, not evidence of execution.

Both actually checked evidence entries are index `0`:

| Events | Locator | Declared and actual digest | Bytes | Result |
|---|---|---|---:|---|
| Check, Review | `git:62ba249ef5cafdee4860900220f826dfad0ba869:proof.txt` | `sha256:c3f58fa85abd4403a63dc44eb205a4be351054f86f0f748865d4094160d3f446` | 77 each | `matching`, `durable: true` |

The brief reports selected-local-frontier scope, `locally_closed`, no completeness issues, locally configured root authority, reviewer independence not established, and global completeness unknown. Those limits apply despite the successful read. The remaining substantive blocker is the open Important finding; acceptance is unrecorded.

**Complete scenario**

Repository: `/tmp/pact-guide-readers-b1e00dd/complete`.

Requested source revision: `fd0a35409b7f10ea96d6f2af192632bb79b5d810`.

Returned frontier:

`sha256:fd02ef612c6699098ce1a501a0aa28fdc5c1c9fbd6a267f257ec4735a8d79211`

Exact event references:

| Label | Full event reference |
|---|---|
| Historical Check | `pact:event:sha256:350c12274338c4dc398850fb86e8d6f640de373f1b37225fba1b22e85b180627#check` |
| Original Review | `pact:event:sha256:350c12274338c4dc398850fb86e8d6f640de373f1b37225fba1b22e85b180627#review` |
| Historical Action | `pact:event:sha256:350c12274338c4dc398850fb86e8d6f640de373f1b37225fba1b22e85b180627#next` |
| Corrected Check | `pact:event:sha256:fd02ef612c6699098ce1a501a0aa28fdc5c1c9fbd6a267f257ec4735a8d79211#check-fixed` |
| Resolving Review | `pact:event:sha256:fd02ef612c6699098ce1a501a0aa28fdc5c1c9fbd6a267f257ec4735a8d79211#review-fixed` |
| Acceptance | `pact:event:sha256:fd02ef612c6699098ce1a501a0aa28fdc5c1c9fbd6a267f257ec4735a8d79211#accept` |

The Corrected Check reports name `unit`, command `["go","test","./..."]`, outcome `passed`, exit code `0`, operation ID `corrected`, and evidence index `0`. Its source revision exactly matches the requested `fd0a35409b7f10ea96d6f2af192632bb79b5d810`.

The Original Review owns `finding-1`, severity `important`, summary “Synthetic input loses a declared fact.” Its source revision is the older `62ba249ef5cafdee4860900220f826dfad0ba869`. The finding is `resolved`; its sole explicit `resolved_by` entry is the Resolving Review above.

The brief exposes that resolution relationship, but no original `resolves` payload. I cannot independently report its correction-source field, selected resolution evidence indexes, review verdict, or causal parent fields.

The Acceptance records `accepted` at source revision `fd0a35409b7f10ea96d6f2af192632bb79b5d810`, operation ID `corrected`. It names:

- `check_refs: ["local:check-fixed"]`, resolving to the Corrected Check.
- `review_refs: ["local:review-fixed"]`, resolving to the Resolving Review.
- Policy `sha256:e9d050d6b7170e608677c0c56b338a888c2ec001499b0119adca52cf0c8fd437`.
- Evidence index `0`.
- Rationale: “The selected check and explicit resolution support the correction.”

`supported_acceptance.status` is `supported`, names the Acceptance ref, and has no reasons. This is the projector’s local interpretation under the returned policy. It does not establish organizational approval or independent review.

The Historical Action remains listed. It declares “Correct finding-1 and review the correction.” Its actor is `fixture-agent`, operation ID is `initial`, and source revision is `62ba249ef5cafdee4860900220f826dfad0ba869`. Its blockers name `local:review` and `finding-1`, resolving to the Original Review above. It selects no evidence. Its source is historical, and the referenced finding is now resolved. Its continued presence does not establish current work.

Five evidence entries were actually assessed, each at index `0`:

| Events | Locator | Declared and actual digest | Bytes | Result |
|---|---|---|---:|---|
| Historical Check, Original Review | `git:62ba249ef5cafdee4860900220f826dfad0ba869:proof.txt` | `sha256:c3f58fa85abd4403a63dc44eb205a4be351054f86f0f748865d4094160d3f446` | 77 each | `matching`, `durable: true` |
| Acceptance, Corrected Check, Resolving Review | `git:fd0a35409b7f10ea96d6f2af192632bb79b5d810:proof.txt` | `sha256:c3f58fa85abd4403a63dc44eb205a4be351054f86f0f748865d4094160d3f446` | 77 each | `matching`, `durable: true` |

The Historical Check appears through its evidence assessment; its check name, outcome, and original payload are absent from this brief. I have not inferred those fields from another scenario.

The brief reports selected-local-frontier scope, `locally_closed`, no completeness issues, locally configured root authority, reviewer independence not established, and global completeness unknown. It reports no open finding or acceptance blocker within that derived state.

**Conflict scenario**

Repository: `/tmp/pact-guide-readers-b1e00dd/conflict`.

Requested source revision: `fd0a35409b7f10ea96d6f2af192632bb79b5d810`.

Returned frontier contains both heads:

- `sha256:456ec8fac697f644eb8ecc661d28566f3a744da62a2bf2818dbb8653e41b49e0`
- `sha256:96d1269696f06954838cdc956b2c5e6dd019bf3bcf95cb6946a69dbf91daeb36`

Exact event references:

| Label | Full event reference |
|---|---|
| Historical Check | `pact:event:sha256:39a4913d4bbe6b60930477f3cd2d1bcaa9f836a4be3fa2296cfebd2adb6c2d37#check` |
| Original Review | `pact:event:sha256:39a4913d4bbe6b60930477f3cd2d1bcaa9f836a4be3fa2296cfebd2adb6c2d37#review` |
| Historical Action | `pact:event:sha256:39a4913d4bbe6b60930477f3cd2d1bcaa9f836a4be3fa2296cfebd2adb6c2d37#next` |
| Accepted-branch Check | `pact:event:sha256:456ec8fac697f644eb8ecc661d28566f3a744da62a2bf2818dbb8653e41b49e0#check-fixed` |
| Accepted-branch Review | `pact:event:sha256:456ec8fac697f644eb8ecc661d28566f3a744da62a2bf2818dbb8653e41b49e0#review-fixed` |
| Accepted Decision | `pact:event:sha256:456ec8fac697f644eb8ecc661d28566f3a744da62a2bf2818dbb8653e41b49e0#accept` |
| Rejected-branch Check | `pact:event:sha256:96d1269696f06954838cdc956b2c5e6dd019bf3bcf95cb6946a69dbf91daeb36#check-fixed` |
| Rejected-branch Review | `pact:event:sha256:96d1269696f06954838cdc956b2c5e6dd019bf3bcf95cb6946a69dbf91daeb36#review-fixed` |
| Rejected Decision | `pact:event:sha256:96d1269696f06954838cdc956b2c5e6dd019bf3bcf95cb6946a69dbf91daeb36#accept` |

Both current checks report name `unit`, command `["go","test","./..."]`, outcome `passed`, exit code `0`, and evidence index `0`. Both bind source revision `fd0a35409b7f10ea96d6f2af192632bb79b5d810`. Their operation IDs differ: `corrected` for the Accepted-branch Check and `rejected` for the Rejected-branch Check.

The Original Review owns `finding-1`, severity `important`, summary “Synthetic input loses a declared fact.” Its source revision is `62ba249ef5cafdee4860900220f826dfad0ba869`. Its status is `resolved`; `resolved_by` explicitly contains both branch Review refs above.

The brief does not expose either original resolving payload, review verdict, correction-source field, selected resolution evidence indexes, or causal parent fields.

Two incompatible decisions remain recorded at the requested source:

| Decision | Recorded value | Operation ID | Dependencies |
|---|---|---|---|
| Accepted Decision | `accepted` | `corrected` | Its own `local:check-fixed` and `local:review-fixed` |
| Rejected Decision | `rejected` | `rejected` | Its own `local:check-fixed` and `local:review-fixed` |

Each local dependency resolves within that decision’s containing object to the corresponding full branch refs above. Both decisions select evidence index `0` and policy `sha256:e9d050d6b7170e608677c0c56b338a888c2ec001499b0119adca52cf0c8fd437`. Both contain the rationale “The selected check and explicit resolution support the correction.” That identical rationale does not override their incompatible decision values.

`supported_acceptance.status` is `unresolved`. Its decision refs contain both decisions. Its sole reason is `concurrent_incompatible_decisions`. Neither head, hash ordering, passing checks, nor resolved finding selects a winner.

The Historical Action declares “Correct finding-1 and review the correction.” Its actor is `fixture-agent`, operation ID is `initial`, and source revision is `62ba249ef5cafdee4860900220f826dfad0ba869`. It names `local:review` and `finding-1` as blockers, resolving to the Original Review above, and selects no evidence. It is historical; its referenced finding is resolved. It is not a newly recorded instruction to resolve the decision conflict.

Eight evidence entries were actually assessed, each at index `0`:

| Events | Locator | Declared and actual digest | Bytes | Result |
|---|---|---|---:|---|
| Historical Check, Original Review | `git:62ba249ef5cafdee4860900220f826dfad0ba869:proof.txt` | `sha256:c3f58fa85abd4403a63dc44eb205a4be351054f86f0f748865d4094160d3f446` | 77 each | `matching`, `durable: true` |
| Accepted Decision, Accepted-branch Check, Accepted-branch Review | `git:fd0a35409b7f10ea96d6f2af192632bb79b5d810:proof.txt` | `sha256:c3f58fa85abd4403a63dc44eb205a4be351054f86f0f748865d4094160d3f446` | 77 each | `matching`, `durable: true` |
| Rejected Decision, Rejected-branch Check, Rejected-branch Review | `git:fd0a35409b7f10ea96d6f2af192632bb79b5d810:proof.txt` | `sha256:c3f58fa85abd4403a63dc44eb205a4be351054f86f0f748865d4094160d3f446` | 77 each | `matching`, `durable: true` |

The Historical Check’s original name and outcome are absent from this brief. Its evidence assessment does not supply them.

The brief reports selected-local-frontier scope, `locally_closed`, no completeness issues, locally configured root authority, reviewer independence not established, and global completeness unknown. Local closure and matching evidence coexist with the unresolved decision conflict.

**Authority, execution, and unread scope**

All three results are derived WorkState observations. I did not read original objects with `show`, run separate `status` or strict verification, inspect signer identities, or independently inspect causal edges. Local root configuration does not prove its own authority. A shared signing key would not establish reviewer independence; the returned state explicitly says independence is not established.

The evidence results establish matching, available bytes at immutable Git locators within the selected repositories. They do not prove that the reported commands or reviews actually occurred. I did not execute `go test ./...`.

No brief exposed pagination or unread-page metadata. No output-limit error, unresolved-reference list, or tool truncation occurred. Original review and parent payloads remain unread under this exercise’s prescribed recipe. Their absent fields remain unknown rather than reconstructed from the derived result.

**Capture and call accounting**

I made exactly **5 `functions.exec` calls and 5 nested `exec_command` calls**:

1. One initial call read the four supplied files together.
2. One call captured the open scenario.
3. One call captured the complete scenario.
4. One call captured the conflict scenario.
5. One final read-only shell call counted bytes, command records, and exits, and hashed the guide.

The captures contain exactly **3 public CLI invocations**, one `brief` per scenario. There were no retries. Internal OS/Git processes were uninstrumented.

| Scenario | CLI stdout bytes, including final newline | CLI stderr bytes | CLI exit | Command records |
|---|---:|---:|---:|---:|
| Open | 3,103 | 0 | 0 | 1 |
| Complete | 5,173 | 0 | 0 | 1 |
| Conflict | 7,791 | 0 | 0 | 1 |
| Total | 16,067 | 0 | — | 3 |

Each stdout fits the default 16,384-byte brief limit. Each `brief.exit` file contains `0\n`, totaling 2 bytes. The command capture files are 290 bytes for open and 294 bytes each for complete and conflict.

The initial file delivery contained:

| File | Exact bytes |
|---|---:|
| `goals.json` | 811 |
| `fact-rubric.md` | 1,173 |
| Operator guide | 12,284 |
| `candidate-read.sh` | 1,011 |
| Total delivered file content | 15,279 |

The full guide was delivered once, without summarization or observed truncation. Its SHA-256 is `735a53a0932f35ae1ee710686a195903a79fcc2461eefa8bbf2584980df31357`. The final counting call exited `0` and returned 851 output bytes. These byte counts exclude tool framing and inherited conversation context, whose exact bytes were not measured.

All five shell calls completed successfully. There were **zero CLI failures, zero observed tool truncations, and zero scenario reruns**. Raw captures remain in `/tmp/pact-guide-readers-b1e00dd/candidate-open`, `candidate-complete`, and `candidate-conflict`.

The supplied evaluation source is `b1e00dd1c9b2280c18af0ce50a65191dc24480d0`. The assigned configuration is `gpt-6.1-sol/high`; deployment build version was unexposed.
