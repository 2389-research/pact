Doctor Biz, the read-only baseline exercise finished. Interpretation below is **manual**, using public `query`, `show`, `verify`, and `evidence check` output. No projector, tests, reported commands, or review work ran.

The frozen evaluation source was `b1e00dd1c9b2280c18af0ce50a65191dc24480d0`. The historical guide came from `082729690e107a66faaff4c94323d34c40e3d7cd` and declares version `0.2.3`. Configured model: `gpt-6.1-sol/high`; deployment build version was unexposed.

For the **open scenario**, captures are in `/tmp/pact-guide-readers-b1e00dd/baseline-open`.

- Namespace: `org/example/development`.
- Subject: `widget/task-1`.
- Requested source: repository `synthetic/widget`, revision `62ba249ef5cafdee4860900220f826dfad0ba869`.
- Inspected local head/cut: `sha256:51436a515b62b9c6f02adba580d70cdbcfdabbb5a687c9573a9e84029b9ca628`.
- The bounded query returned all three events, with `has_more:false` and `unresolved:[]`. No checkpoint existed.

The recorded check is:

`pact:event:sha256:51436a515b62b9c6f02adba580d70cdbcfdabbb5a687c9573a9e84029b9ca628#check`

Its name is `unit`. It records `["go","test","./..."]`, outcome `passed`, and exit code `0`. Its exact source is `synthetic/widget@62ba249ef5cafdee4860900220f826dfad0ba869`. These are signed reported facts; this exercise did not execute that command.

The recorded review is:

`pact:event:sha256:51436a515b62b9c6f02adba580d70cdbcfdabbb5a687c9573a9e84029b9ca628#review`

It records `changes_required` at the same source. Finding `finding-1` has severity `important` and summary `Synthetic input loses a declared fact.` Its `resolves` array is empty. No later resolving event appears in the complete selected subject query. The finding remains **open** under the guide’s manual interpretation.

The declared action is:

`pact:event:sha256:51436a515b62b9c6f02adba580d70cdbcfdabbb5a687c9573a9e84029b9ca628#next`

Actor `fixture-agent` declared: `Correct finding-1 and review the correction.` Its own source is `synthetic/widget@62ba249ef5cafdee4860900220f826dfad0ba869`. Both its blocking event and its blocking finding point to the full review ref above, with finding ID `finding-1`. This is a historical declaration, not proof of current activity.

No acceptance decision was recorded. Manual acceptance is **not_recorded**, with the Important finding and changes-required review blocking support. The passing check does not close the finding.

Evidence was actually checked for the check and review refs above. Both selected:

- Locator: `git:62ba249ef5cafdee4860900220f826dfad0ba869:proof.txt`.
- Recorded and actual digest: `sha256:c3f58fa85abd4403a63dc44eb205a4be351054f86f0f748865d4094160d3f446`.
- Result: `matching`, `77` bytes for each assessment.
- Durable source: the full Git revision and `proof.txt` path, while those Git objects remain retained.

The action carries the same evidence entry, but selects no evidence indexes. The recipe did not check that action separately.

Strict verification reported one commit, three events, valid integrity/authenticity/structure, no errors or warnings, and a current index. Authorization was `authorized` because its signer is a locally bootstrapped trusted root:

`ed25519:sha256:e942621aa24ccf332822a3f46e41f14c7aa0985cab1e50b6c66c8c1b643675ce`

That proves authority only relative to local trust configuration. Bootstrap authority remains external. A shared signing key does not establish reviewer independence. The replica was `locally_closed`; global completeness remained `unknown`. No unread pages, unresolved references, CLI failures, or diagnostic truncations were reported. No ledger mutation or index rebuild occurred.

For the **complete scenario**, captures are in `/tmp/pact-guide-readers-b1e00dd/baseline-complete`.

- Namespace: `org/example/development`.
- Subject: `widget/task-1`.
- Requested source: repository `synthetic/widget`, revision `fd0a35409b7f10ea96d6f2af192632bb79b5d810`.
- Inspected local head/cut: `sha256:fd02ef612c6699098ce1a501a0aa28fdc5c1c9fbd6a267f257ec4735a8d79211`.
- That head parents `sha256:350c12274338c4dc398850fb86e8d6f640de373f1b37225fba1b22e85b180627`.
- The bounded query returned all six events, with `has_more:false` and `unresolved:[]`. No checkpoint existed.

The historical check is:

`pact:event:sha256:350c12274338c4dc398850fb86e8d6f640de373f1b37225fba1b22e85b180627#check`

It records `unit`, command `["go","test","./..."]`, outcome `passed`, and exit code `0`. Its source is the older `synthetic/widget@62ba249ef5cafdee4860900220f826dfad0ba869`; it does not verify the requested correction revision.

The historical review is:

`pact:event:sha256:350c12274338c4dc398850fb86e8d6f640de373f1b37225fba1b22e85b180627#review`

At that older source, it records `changes_required` and Important finding `finding-1`: `Synthetic input loses a declared fact.`

The historical action is:

`pact:event:sha256:350c12274338c4dc398850fb86e8d6f640de373f1b37225fba1b22e85b180627#next`

Actor `fixture-agent` declared `Correct finding-1 and review the correction.` Its blocking event and finding both identify the historical review ref above and finding ID `finding-1`. Its own source remains `synthetic/widget@62ba249ef5cafdee4860900220f826dfad0ba869`. It remains historical despite still appearing in the query.

The requested-source check is:

`pact:event:sha256:fd02ef612c6699098ce1a501a0aa28fdc5c1c9fbd6a267f257ec4735a8d79211#check-fixed`

It records `unit`, command `["go","test","./..."]`, outcome `passed`, and exit code `0`, scoped exactly to `synthetic/widget@fd0a35409b7f10ea96d6f2af192632bb79b5d810`.

The resolving review is:

`pact:event:sha256:fd02ef612c6699098ce1a501a0aa28fdc5c1c9fbd6a267f257ec4735a8d79211#review-fixed`

It records `approved`, no new findings, and an explicit resolution of `finding-1` from the historical review ref above. Its `correction_source` is exactly `synthetic/widget@fd0a35409b7f10ea96d6f2af192632bb79b5d810`, with evidence index `[0]`. The Important finding is therefore **explicitly resolved** in the manual interpretation.

The acceptance decision is:

`pact:event:sha256:fd02ef612c6699098ce1a501a0aa28fdc5c1c9fbd6a267f257ec4735a8d79211#accept`

It records `accepted` for the requested source. Its exact dependencies are:

- Check: `pact:event:sha256:fd02ef612c6699098ce1a501a0aa28fdc5c1c9fbd6a267f257ec4735a8d79211#check-fixed`.
- Review: `pact:event:sha256:fd02ef612c6699098ce1a501a0aa28fdc5c1c9fbd6a267f257ec4735a8d79211#review-fixed`.
- Both also appear as explicit `caused_by` links.
- Policy: `sha256:e9d050d6b7170e608677c0c56b338a888c2ec001499b0119adca52cf0c8fd437`.
- Rationale: `The selected check and explicit resolution support the correction.`

Manual local acceptance is **supported**: the selected exact-source check passed, the review approved an explicit resolution, selected evidence matched durable Git locators, and local authority was known. This is a manual application of the historical guide, not executed projection output or organizational approval. No competing decision appeared in the selected local history.

Evidence was checked for five events:

- Historical `#check` and `#review` selected `git:62ba249ef5cafdee4860900220f826dfad0ba869:proof.txt`.
- Corrected `#accept`, `#check-fixed`, and `#review-fixed` selected `git:fd0a35409b7f10ea96d6f2af192632bb79b5d810:proof.txt`.
- Every assessment matched the recorded digest `sha256:c3f58fa85abd4403a63dc44eb205a4be351054f86f0f748865d4094160d3f446`.
- Each assessment resolved `77` bytes. The two revisions are distinct source scopes despite identical proof bytes.
- The historical action selected no evidence indexes and received no separate evidence check.

Strict verification reported two commits, six events, valid integrity/authenticity/structure, no errors or warnings, and a current index. Both commits were locally authorized under root:

`ed25519:sha256:7a681488e2380b8f77ed2df883a9ea2cc0e1eb5f3cb5529cedeba8941c8a6ea3`

Local bootstrap authority does not establish external organizational authority. The shared key does not prove independent review. The replica was locally closed with unknown global completeness. No unread pages, unresolved references, CLI failures, or diagnostic truncations were reported. No ledger mutation or index rebuild occurred.

For the **conflict scenario**, captures are in `/tmp/pact-guide-readers-b1e00dd/baseline-conflict`.

- Namespace: `org/example/development`.
- Subject: `widget/task-1`.
- Requested source: repository `synthetic/widget`, revision `fd0a35409b7f10ea96d6f2af192632bb79b5d810`.
- Inspected head/cut includes both:
  - `sha256:456ec8fac697f644eb8ecc661d28566f3a744da62a2bf2818dbb8653e41b49e0`
  - `sha256:96d1269696f06954838cdc956b2c5e6dd019bf3bcf95cb6946a69dbf91daeb36`
- Both heads parent `sha256:39a4913d4bbe6b60930477f3cd2d1bcaa9f836a4be3fa2296cfebd2adb6c2d37`; neither head observes the other.
- The bounded query returned all nine events, with `has_more:false` and `unresolved:[]`. No checkpoint existed.

The historical check is:

`pact:event:sha256:39a4913d4bbe6b60930477f3cd2d1bcaa9f836a4be3fa2296cfebd2adb6c2d37#check`

It records `unit`, `["go","test","./..."]`, `passed`, exit code `0`, at older source `synthetic/widget@62ba249ef5cafdee4860900220f826dfad0ba869`.

The historical review is:

`pact:event:sha256:39a4913d4bbe6b60930477f3cd2d1bcaa9f836a4be3fa2296cfebd2adb6c2d37#review`

It records `changes_required` at that older source. Its Important finding is `finding-1`: `Synthetic input loses a declared fact.`

The historical action is:

`pact:event:sha256:39a4913d4bbe6b60930477f3cd2d1bcaa9f836a4be3fa2296cfebd2adb6c2d37#next`

Actor `fixture-agent` declared `Correct finding-1 and review the correction.` It blocks on the historical review ref above and its `finding-1`. Its own source is the older `synthetic/widget@62ba249ef5cafdee4860900220f826dfad0ba869`. Its listing does not establish current work.

The first concurrent branch contains:

- `pact:event:sha256:456ec8fac697f644eb8ecc661d28566f3a744da62a2bf2818dbb8653e41b49e0#check-fixed`
- `pact:event:sha256:456ec8fac697f644eb8ecc661d28566f3a744da62a2bf2818dbb8653e41b49e0#review-fixed`
- `pact:event:sha256:456ec8fac697f644eb8ecc661d28566f3a744da62a2bf2818dbb8653e41b49e0#accept`

The check records `unit`, `["go","test","./..."]`, `passed`, exit code `0`. The review records `approved`, no new findings, and explicitly resolves the historical review’s `finding-1`. Both source and resolution correction source are `synthetic/widget@fd0a35409b7f10ea96d6f2af192632bb79b5d810`. The resolution selects evidence `[0]`.

That branch’s decision records `accepted`. Its check/review dependencies and `caused_by` links are the full branch check and review refs immediately above. Its policy is `sha256:e9d050d6b7170e608677c0c56b338a888c2ec001499b0119adca52cf0c8fd437`.

The second concurrent branch contains:

- `pact:event:sha256:96d1269696f06954838cdc956b2c5e6dd019bf3bcf95cb6946a69dbf91daeb36#check-fixed`
- `pact:event:sha256:96d1269696f06954838cdc956b2c5e6dd019bf3bcf95cb6946a69dbf91daeb36#review-fixed`
- `pact:event:sha256:96d1269696f06954838cdc956b2c5e6dd019bf3bcf95cb6946a69dbf91daeb36#accept`

Its check also records `unit`, `["go","test","./..."]`, `passed`, exit code `0`. Its review records `approved`, no new findings, and explicitly resolves the same historical review’s `finding-1`. Both source and correction source are the requested `synthetic/widget@fd0a35409b7f10ea96d6f2af192632bb79b5d810`, with resolution evidence `[0]`.

Despite local ID `accept`, that second branch’s decision is **`rejected`**. Its exact dependencies and `caused_by` links are its own full check/review refs immediately above. It names the same policy digest. Both branches use rationale `The selected check and explicit resolution support the correction.` The rationale does not override the explicit decision value.

The original finding has two explicit resolving review records. However, acceptance remains **unresolved** under manual interpretation because concurrent accepted and rejected decisions conflict. No event supersedes either decision, and no merge resolves them. I selected no winner by timestamp, hash, query order, or fixture name. The raw query’s empty `unresolved` list concerns query references; it does not resolve this semantic conflict.

Evidence was checked for eight events:

- Historical `#check` and `#review` selected `git:62ba249ef5cafdee4860900220f826dfad0ba869:proof.txt`.
- Each concurrent branch’s `#accept`, `#check-fixed`, and `#review-fixed` selected `git:fd0a35409b7f10ea96d6f2af192632bb79b5d810:proof.txt`.
- Every recorded and actual digest was `sha256:c3f58fa85abd4403a63dc44eb205a4be351054f86f0f748865d4094160d3f446`.
- Every assessment reported `matching`, `77` bytes.
- These are immutable Git locators while the required objects remain retained. The historical action selected no evidence indexes and received no separate check.

Strict verification reported three commits, nine events, valid integrity/authenticity/structure, no errors or warnings, and a current index. All commits were locally authorized under root:

`ed25519:sha256:5b14db149e3afa44cc2949cd053a65af3e23df870136c8b00ec9fde1d31db9b4`

The local trust root cannot prove its bootstrap authority. Its shared key does not prove reviewer independence. Local closure does not establish global completeness, which remained unknown. No unread pages, unresolved references, CLI failures, or diagnostic truncations were reported. The semantic decision conflict remains the blocker. No ledger mutation or index rebuild occurred.

Across all scenarios, raw verification checked ledger structure, integrity, signatures, DAG, references, and local-root authorization. It did **not** execute arbitrary domain schemas or the named projection policy. Matching evidence and signatures do not prove that the recorded checks or reviews occurred. No external synchronization or global completeness check ran.

The recipe accepts a revision argument but does not use it to filter CLI reads. Consequently, each capture includes historical sources. I preserved those scopes manually instead of treating every listed event as requested-source evidence. This did not cause a rerun.

The accounting is:

| Item | Open | Complete | Conflict | Total |
|---|---:|---:|---:|---:|
| CLI invocations | 5 | 9 | 13 | 27 |
| Query / verify / show / evidence | 1 / 1 / 1 / 2 | 1 / 1 / 2 / 5 | 1 / 1 / 3 / 8 | 3 / 3 / 6 / 15 |
| Captured stdout bytes | 8,742 | 16,874 | 24,968 | 50,584 |
| Captured stderr bytes | 0 | 0 | 0 | 0 |
| Nonzero captured exits | 0 | 0 | 0 | 0 |
| `commands.jsonl` bytes | 1,302 | 2,647 | 3,972 | 7,921 |

All 27 captured stdout streams include their terminal newline in those byte totals. Every captured exit was `0`. Recipe executions each ran once; no partial failure required retry.

There were exactly **5 `functions.exec` calls and 5 inner `exec_command` calls**: one initial four-file read, three scenario executions, and one final read-only counting call. The counting call ran no CLI commands.

Initial raw context delivery was **46,716 bytes**: goals `811`, rubric `1,173`, full historical guide `42,710`, and recipe `2,022`. The guide was delivered once, verbatim, without observed truncation. The final counting output was **7,451 bytes**, including its newline. Total raw stdout delivered by those five calls was **104,751 bytes**. These totals exclude tool wrapper text, instructions, and this handoff.

Observed tool-output truncations: **0**. CLI diagnostic truncations: **0**. Internal OS, shell, Ruby, `jq`, and Git subprocesses were not instrumented as CLI invocations. No repository implementation, tests, driver, oracle, expected fixtures, broad reports, or prior transcripts were opened.
